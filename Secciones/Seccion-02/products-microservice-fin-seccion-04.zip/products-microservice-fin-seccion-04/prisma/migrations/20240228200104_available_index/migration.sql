-- CreateIndex
CREATE INDEX "Product_available_idx" ON "Product"("available");
